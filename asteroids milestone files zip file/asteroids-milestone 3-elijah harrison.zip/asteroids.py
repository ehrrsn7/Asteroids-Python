"""
File:   Asteroids.py
Author: Elijah Harrison

ABOVE AND BEYOND:

- Dark Mode
(press D to toggle)
- Game States
(not quite successfully implemented, but started)
(technically, P will set the game to 'pause')
- Bob
(press K to release the kraken(s). His name is Bob.)
- Fire bullet
(Pressing SPACE serves as an 
 alternative to clicking the mouse)
"""

"""
Import
"""
# import python libraries
import arcade, random, math

# import author's files
from ship               import Ship
from ship               import Ship_Lives_Icon
from bullet             import Bullet
from rocks              import Rock_Big
from rocks              import Rock_Medium
from rocks              import Rock_Small
from projectile         import Projectile
from velocity           import Velocity
from velocity           import Velocity_Calculator
from point              import Point
from on_screen_text     import Score
from on_screen_text     import Level
from gamestate          import Gamestate
from gamestate_screens  import Gamestate_Screens

# import global variables directory,
# save all variables we will need
# These are Global constants to use throughout the game
import global_variables_directory as global_variables

# grab some for easy reference
DEBUG         = global_variables.DEBUG
SCREEN_HEIGHT = global_variables.SCREEN_HEIGHT
SCREEN_WIDTH  = global_variables.SCREEN_WIDTH
ALIVE         = global_variables.ALIVE
DEAD          = global_variables.DEAD

"""
Class: Game
This class handles all the game callbacks and interaction
It assumes the following classes exist:
    Ship
    Rock (and it's sub-classes)
    Point
    Velocity
    Bullet
This class will then call the appropriate functions of
each of the above classes.
You are welcome to modify anything in this class, but mostly
you shouldn't have to. There are a few sections that you
must add code to.
"""
class Game(arcade.Window):
    # dark mode
    dark_mode = global_variables.DARK_MODE_INIT

    def __init__(self, width, height):
        """
        Sets up the initial conditions of the game
        :param width:  Screen width
        :param height: Screen height
        """
        super().__init__(width, height)

        # background color
        self.background_color = global_variables.SCREEN_COLOR_DARK
        arcade.set_background_color(self.background_color)

        # "held keys"
        # this line of code is to initialize a list of "Held keys"
        # If we don't do it this way, then keys will be "pressed" 
        # but not "held"
        self.held_keys = set()

        # initialize Projectiles
        self.ship    = Ship() # initialize ship
        self.lives   = [    ] # initialize ship lives list
        self.bullets = [    ] # initialize bullets list
        self.rocks   = [    ] # initialize rocks list

        # game must start with 5 rocks
        self.initialize_rocks()
        # game must start with 3 ship lives
        self.initialize_ship_lives()

        # initialize On_Screen_Text objects
        self.score                  = Score()
        self.level                  = Level()
        self.screens                = Gamestate_Screens()

        # other objects
        self.velocity_calculator    = Velocity_Calculator()

        # game state
        self.gamestate = Gamestate()

        # other 'draw objects'-related states
        self.release_kraken     = False # release the kraken
        self.hints              = False # display hints
        self.mach_gun_activated = True
        self.machine_gun_timer  = 0

    def initialize_rocks(self):
        # initialing method:
        # game must begin with 5 rocks on the screen
        # therefore, __init__ must either do this 
        # explicitly or call this method.
        for _i in range(global_variables.ROCK_INIT_AMOUNT):
            if global_variables.DEBUG: print(f"Initializing rock: {_i+1}")
            new_rock = Rock_Big()
            if DEBUG: print("Making new rock", _i + 1)
            self.rocks.append(new_rock)
        if DEBUG:
            print("New rocks[] amount after calling self.initialize_rocks():",
                  len(self.rocks))

    def initialize_ship_lives(self):
        # initialize first ship life's position coordinates
        x_init  = global_variables.SHIP_LIVES_X_POSITION_INIT
        y       = global_variables.SHIP_LIVES_Y_POSITION

        # initialize no. of ships to be made
        ship_lives_amount = global_variables.SHIP_LIVES_INIT_AMOUNT

        # now, make the ship life icons
        for _i in range(ship_lives_amount):
            if global_variables.DEBUG:
                print(f"Initializing ship life icon {_i + 1} of {ship_lives_amount}")

            # make new icons
            new_ship_life_icon = Ship_Lives_Icon(Point(x_init, y))

            # set the new icon location x value a 
            # certain amount of pixels to the right
            x_init += global_variables.SHIP_LIVES_X_POSITION_SPACING
            self.lives.append(new_ship_life_icon)

    """
    DRAW
    - on_draw
    - draw all objects
        * draw ship
        * draw ship life icons
        * draw bullets
        * draw bullets
        * draw rocks
        # draw on screen text
    """
    def on_draw(self):
        """
        Called automatically by the arcade framework.
        Handles the responsibility of drawing all elements.
        """

        # clear the screen to begin drawing
        arcade.start_render()
        self.draw_all_objects()

    # on_draw submethods
    def draw_all_objects(self):
        self.draw_ship()
        self.draw_ship_life_icons()
        self.draw_bullets()
        self.draw_rocks()
        self.draw_on_screen_text()

    def draw_ship(self):
        self.ship.draw()

    def draw_ship_life_icons(self):
        for ship_life_icon in self.lives:
            ship_life_icon.draw()

    def draw_bullets(self):
        if self.is_state_show_all_objects():
            for bullet in self.bullets:
                bullet.draw()

    def draw_rocks(self):
        for rock in self.rocks:
            rock.draw()

    def draw_on_screen_text(self):
        
        self.score.draw()
        
        self.level.draw()
        
        if self.is_main_menu():
            self.screens.main_menu_screen.draw()
        
        self.gamestate.draw()
        
        if self.is_ship_was_hit():
            self.screens.ship_was_hit_msg.draw()

        if self.is_game_over():
            self.screens.game_over_screen.draw()

        if self.hints:
            self.screens.hints_screen.draw()


    """""""""""""""
    #   ADVANCE   #
    """""""""""""""
    def update(self, delta_time):
        """
        Update each object in the game.
        :param delta_time: tells us how much time has actually elapsed
        """

        # handle events
        self.check_collisions()
        self.check_keys()

        # handle objects
        self.advance_all_projectiles()
        self.wrap_objects()


    def advance_all_projectiles(self):
        self.advance_rocks()
        self.advance_bullets()
        self.ship.advance()

    def advance_rocks(self):
        for rock in self.rocks:
            rock.advance()
        if len(self.rocks) == 0:
            if not self.is_new_level():
                self.new_level()

    def advance_bullets(self):
        for bullet in self.bullets:
            bullet.advance()

    """
    WRAP

    wrap(proj) is to be called to check 
    if any of the Projectiles 
    (the ship, or any bullets or rocks)
    have left the screen;
    in each of these cases, the individual 
    Projectile's position must be updated 
    for it to appear on the opposite side 
    of the screen.

    wrap_objects() simply calls wrap(proj)
    for each of the Projectile objects in
    the game.
    """
    def wrap_objects(self):
        buffer = 0
        # wrap ship
        if self.is_off_screen(self.ship, buffer):
            self.wrap(self.ship)
        # self.wrap(self.ship)

        # wrap bullets
        for bullet in self.bullets:
            if self.is_off_screen(bullet, buffer):
                self.wrap(bullet)
            # self.wrap(bullet)


        # wrap rocks
        for rock in self.rocks:
            if self.is_off_screen(rock, buffer):
                self.wrap(rock)
            # self.wrap(rock)

    def wrap(self, proj: Projectile):

        left_side_x  = 5
        right_side_x = global_variables.SCREEN_WIDTH - 5

        bottom_y     = 5
        top_y        = global_variables.SCREEN_HEIGHT - 5

        # if projectile goes off of left side, 
        # send it to the right
        if   proj.center.x < left_side_x:
            proj.center.x  = right_side_x
            if global_variables.DEBUG: print("Object reached left side")

        # or conversely, if projectile goes off 
        # of right side, send it to the left
        elif proj.center.x > right_side_x:
            proj.center.x  = left_side_x
            if global_variables.DEBUG: print("Object reached right side")

        # same process with the top and bottom:

        # if projectile goes off of left side, 
        # send it to the right
        if   proj.center.y > top_y:
            proj.center.y  = bottom_y
            if global_variables.DEBUG: print("Object reached top")

        # or conversely, if projectile goes off 
        # of right side, send it to the left
        elif proj.center.y < bottom_y:
            proj.center.y  = top_y
            if global_variables.DEBUG: print("Object reached bottom")

        # take note that each of the if statements have
        # a < or > symbol, and NOT a <= or >=
        # ...this is imperitve to having the objects 
        # being not sent into tHE ABYSS. ("dun dun duUUUUNNNNN")

    """
    EVENTS (HANDLE INPUT)
    """
    def on_key_press(self, key: int, modifiers: int):

        # (actions handled in self.check_keys())
        if key == arcade.key.SPACE:
            if not DEBUG: print("Adding key...")
            self.held_keys.add(key)
        
        if key == arcade.key.RIGHT:
            if not DEBUG: print("Adding key...")
            self.held_keys.add(key)

        if key == arcade.key.LEFT:
            if not DEBUG: print("Adding key...")
            self.held_keys.add(key)

        if key == arcade.key.UP: 
            if not DEBUG: print("Adding key...")
            self.held_keys.add(key)

        if key == arcade.key.R:
            if not DEBUG: print("Adding key...")
            self.held_keys.add(key)

        # state events:
        # pause
        if key == arcade.key.P:
            if not DEBUG: print("'P' was pressed.")
            if not DEBUG: print("Pausing game")
            self.pause()

        # display events:
        # release the kraken
        if key == arcade.key.K:
            if not DEBUG: print("'K' was pressed.")
            if not DEBUG: print("Release the Kraken.")
            self.troll()

        # hints
        if key == arcade.key.H:
            if not DEBUG: print("'H' was pressed.")
            if not DEBUG: print("Display hints.")
            self.toggle_hints()

        # dark mode
        if key == arcade.key.D:
            if not DEBUG: print("'H' was pressed.")
            if not DEBUG: print("Display hints.")
            self.toggle_dark_mode()

        # STATE: PAUSE
        if self.is_pause():
            if not DEBUG: print("In self.on_key_press()")
            if not DEBUG: print("self.gamestate.state == PAUSE")

        # STATE: MAIN_MENU
        elif self.is_main_menu():
            if not DEBUG: print("In self.on_key_press()")
            if not DEBUG: print("self.gamestate.state == MAIN_MENU")

        # STATE: NEXT_LEVEL
        elif self.is_new_level():
            if not DEBUG: print("In self.on_key_press()")
            if not DEBUG: print("self.gamestate.state == NEW LEVEL")

        # STATE: GAME_OVER
        elif self.is_game_over():
            if not DEBUG: print("In self.on_key_press()")
            if not DEBUG: print("self.gamestate.state == GAME_OVER")


        # # STATE: MAIN_MENU, PAUSE, GAME_OVER
        # else:
        #     if key == arcade.key.SPACE: self.resume()

    def check_keys(self):
        # this method has the same purpose as on_key_press()..
        # HOWEVER, this method is called by on_update(), not 
        # the arcade mainframe itself; 
        # also, when this function is called, its keys being 
        # held will hold the event for more than just one frame. 
        # (# MACHINE GUN TIME)

        # this method also relies on self.on_key_press():
        # whenever a button is pressed, that button must be
        # ADDED onto self.held_keys (initialized by line of 
        # code in __init__())
        # we must also take it out in on_key_release()
        if arcade.key.SPACE in self.held_keys:
            if not DEBUG: print("arcade.key.SPACE in self.held_keys")
            if self.is_resume(): self.fire_bullet()
            if self.is_main_menu(): self.resume()

        if arcade.key.UP in self.held_keys:
            if not DEBUG: print("arcade.key.UP in self.held_keys")
            if self.is_resume(): self.ship.accelerate()

        if arcade.key.LEFT in self.held_keys:
            if not DEBUG: print("arcade.key.LEFT in self.held_keys")
            if self.is_resume(): self.ship.rotate_left()

        if arcade.key.RIGHT in self.held_keys:
            if not DEBUG: print("arcade.key.RIGHT in self.held_keys")
            if self.is_resume(): self.ship.rotate_right()

        if arcade.key.R in self.held_keys:
            if self.is_game_over(): self.restart_game()
            elif not self.is_resume(): self.resume()

    def on_key_release(self, key: int, modifiers: int):
        """
        Removes the current key from the set of held keys.
        """
        if key in self.held_keys:
            if not DEBUG: print("Removing key...")
            self.held_keys.remove(key)

    # other event helper methods:
    def fire_bullet(self):
        # create Bullet
        new_bullet = self.ship.fire()

        # add that Bullet to self.bullets[]
        self.bullets.append(new_bullet)

    def restart_game(self):
        self.__init__(SCREEN_WIDTH, SCREEN_HEIGHT)


    """""""""""""""""""""
    CHECK COLLISIONS
    - check collisions
    - check collisions between rock and ship
    - check collisions between rock and bullets
    - check too close
    - clean up zombies
    """""""""""""""""""""
    def check_collisions(self):
        """
        Checks to see if bullets have hit rocks.
        Updates scores and removes dead items.
        :return:
        """

        # when gamestate is not RESUME, 
        # do not count collisions
        if self.is_resume():
            for rock in self.rocks:
                self.check_collisions_between_rock_and_ship(rock)
                self.check_collisions_between_rock_and_bullets(rock)

                # We will wait to remove the dead objects until after we
                # finish going through the list

        # Now, check for anything that is dead, and remove it
        self.cleanup_zombies()

    def check_collisions_between_rock_and_ship(self, rock):
        """
        Collision between rocks and ship
        """
        # now, check if the ship collided with any of the rocks
        if rock.alive and self.ship.alive:
            if DEBUG: print(f"rock, ship radii: {rock.radius}, {self.ship.radius}")

            if self.check_too_close(rock, self.ship):
                # it's a hit!
                if DEBUG: print(f"{rock.name} and Ship were too close")
                if DEBUG: print(f"{     rock.name:10} radius: {     rock.radius}")
                if DEBUG: print(f"{self.ship.name:10} radius: {self.ship.radius}")

                self.ship_was_hit()
                rock.hit()

                if rock.name == "Large asteroid" or rock.name == "Medium asteroid":
                        new_rock1, new_rock2 = rock.split()
                        self.rocks.append(new_rock1)
                        self.rocks.append(new_rock2)

    def check_collisions_between_rock_and_bullets(self, rock):
        """
        Collision between rocks and bullets
        """
        for bullet in self.bullets:

            # Make sure they are both alive before checking for a collision
            if bullet.alive and rock.alive:
                if DEBUG: print(f"bullet, rock radii: {bullet.radius}, {rock.radius}")

                if self.check_too_close(rock, bullet):
                    # it's a hit!
                    if DEBUG: print(f"\n{rock.name} and {bullet.name} were too close")
                    bullet.hit()
                    self.score.score += rock.hit()

                    if rock.name == "Large asteroid" or rock.name == "Medium asteroid":
                        new_rock1, new_rock2 = rock.split()
                        self.rocks.append(new_rock1)
                        self.rocks.append(new_rock2)

    def check_too_close(self, projectile1, projectile2):
        if DEBUG: print(
            f"check_too_close({projectile1.name.upper()}, {projectile2.name.upper()}) called")
        too_close = projectile1.radius   + projectile2.radius
        return (abs(projectile1.center.x - projectile2.center.x) < too_close and
                abs(projectile1.center.y - projectile2.center.y) < too_close)

    def cleanup_zombies(self):
        """
        Removes any dead bullets or rocks from the list.
        """
        # clear any bullets that were hit
        for bullet in self.bullets:
            if not bullet.alive:
                self.bullets.remove(bullet)
                if DEBUG: print("Cleaning up zombie 🧟‍♂️")

        # clear any rocks that were hit
        for rock in self.rocks:
            if not rock.alive:
                self.rocks.remove(rock)
                if DEBUG: print("Cleaning up zombie 🧟‍♂️")


    """
    IS ON SCREEN
    - is off screen
    - is on  screen
    """
    def is_off_screen(self, proj: Projectile, buffer = 10):
        return not self.is_on_screen(proj, buffer)

    def is_on_screen(self, proj: Projectile, buffer = 10):

        if ((proj.center.x > buffer and proj.center.x < global_variables.SCREEN_WIDTH  - buffer) and
            (proj.center.y > buffer and proj.center.y < global_variables.SCREEN_HEIGHT - buffer)):

            return True

        else:
            if global_variables.DEBUG: print("Projectile is off screen")
            return False


    """
    CLEAR OBJECTS
    - clear all objects
    - clear all bullets
    - clear all rocks
    """
    def clear_all_objects(self):
        self.clear_all_bullets()
        self.clear_all_rocks()
        self.initialize_rocks()
        self.ship.__init__()
        self.score.__init__()

    def clear_all_bullets(self):
        for bullet in self.bullets:
            self.bullets.remove(bullet)
            bullet = None

    def clear_all_rocks(self):
        while len(self.rocks) != 0:
            self.rocks.pop()
            if global_variables.DEBUG:
                print("Removing rock")

        if global_variables.DEBUG:
            print("Rocks[] amount after clearing all rocks:",
                  len(self.rocks))


    """""""""""""""
    # GAME STATE  #
    """""""""""""""
    # gamestate property
    @property
    def state(self): return self.gamestate.state
    
    @state.setter
    def state(self, new_value: int):
        # To set the state to a value, we must set 
        # the state attribute within self.gamestate
        self.gamestate.state = new_value
        if not global_variables.DEBUG: print("New", self.gamestate.text)

    # setters
    def resume(self):
        if not DEBUG: print("self.resume() called")
        self.state =  global_variables.RESUME

    def pause(self):
        if not DEBUG: print("self.pause() called")
        self.state =  global_variables.PAUSE

    def main_menu(self):
        if not DEBUG: print("self.main_menu() called")
        self.state =  global_variables.MAIN_MENU

    def new_level(self):
        if not DEBUG: print("self.new_level() called")
        # set new state
        self.state =  global_variables.NEW_LEVEL
        # increment level: (int) text value on screen
        self.level.next_level()

    def game_over(self):
        if not DEBUG: print("self.game_over() called")
        self.state =  global_variables.GAME_OVER

    def ship_was_hit(self):
        if not DEBUG: print("self.ship_was_hit() called")
        self.state =  global_variables.SHIP_WAS_HIT
        if not DEBUG: print(f"{self.ship.name}.hit()")
        self.ship.hit()

        # remove one of the ship lives and keep going
        if len(self.lives) > 1:
            self.lives.pop()
        else:
            self.game_over()

    # getters
    def is_resume(self):        return  self.state == global_variables.RESUME
    def is_pause(self):         return  self.state == global_variables.PAUSE
    def is_main_menu(self):     return  self.state == global_variables.MAIN_MENU
    def is_new_level(self):     return  self.state == global_variables.NEW_LEVEL
    def is_game_over(self):     return  self.state == global_variables.GAME_OVER
    def is_ship_was_hit(self):  return  self.state == global_variables.SHIP_WAS_HIT

    def is_state_show_all_objects(self):
        return (self.is_resume()    or
                self.is_pause()     or
                self.is_new_level() or
                self.is_game_over() or
                self.is_ship_was_hit())
    
    def is_state_advance_all_objects(self):
        return (self.is_resume())

    def troll(self): self.release_kraken = self.toggle(self.release_kraken)
    def toggle_hints(self): self.hints   = self.toggle(self.hints)

    def toggle(self, conditional):
        if conditional: return False
        else:           return True

    def set_machine_gun_timer(self):
        self.machine_gun_timer = global_variables.SHIP_FIRING_RATE_DELAY



# Creates the game and starts it going
window = Game(SCREEN_WIDTH, SCREEN_HEIGHT)
arcade.run()