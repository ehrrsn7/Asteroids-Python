# gamestate screen displays.py
# Elijah Harrison

# import
import global_variables_directory as global_variables
import arcade
from point import Point

"""
Main Menu Screen
"""
class Main_Menu_Screen:
    def draw(self):
        arcade.draw_scaled_texture_rectangle(
            global_variables.SCREEN_CENTER_X, 
            global_variables.SCREEN_CENTER_Y, 
            global_variables.MAIN_MENU_IMAGE_TEXTURE, 
            global_variables.DEFAULT_TEXTURE_SCALE,
            global_variables.DEFAULT_TEXTURE_ANGLE,
            global_variables.DEFAULT_TEXTURE_ALPHA)

class Ship_Was_Hit_Screen:
    def draw(self):
        arcade.draw_scaled_texture_rectangle(
            global_variables.SCREEN_CENTER_X, 
            global_variables.SCREEN_CENTER_Y + 20, 
            global_variables.SHIP_WAS_HIT_IMAGE_TEXTURE, 
            global_variables.DEFAULT_TEXTURE_SCALE / 2,
            global_variables.DEFAULT_TEXTURE_ANGLE,
            global_variables.DEFAULT_TEXTURE_ALPHA)

class Game_Over_Screen:
    def draw(self):
        arcade.draw_scaled_texture_rectangle(
            global_variables.SCREEN_CENTER_X, 
            global_variables.SCREEN_CENTER_Y + 20, 
            global_variables.GAME_OVER_IMAGE_TEXTURE, 
            global_variables.DEFAULT_TEXTURE_SCALE / 2,
            global_variables.DEFAULT_TEXTURE_ANGLE,
            global_variables.DEFAULT_TEXTURE_ALPHA)

class Hints_Screen:
    def draw(self):
        arcade.draw_scaled_texture_rectangle(
            global_variables.SCREEN_CENTER_X, 
            global_variables.SCREEN_CENTER_Y + 20, 
            global_variables.HINTS_IMAGE_TEXTURE, 
            global_variables.DEFAULT_TEXTURE_SCALE / 2,
            global_variables.DEFAULT_TEXTURE_ANGLE,
            global_variables.DEFAULT_TEXTURE_ALPHA)

class Gamestate_Screens:
    def __init__(self):
        self.main_menu_screen = Main_Menu_Screen()
        self.ship_was_hit_msg = Ship_Was_Hit_Screen()
        self.game_over_screen = Game_Over_Screen()
        self.hints_screen     = Hints_Screen()
