"""
Class: 
Components:
"""

# import
import arcade

from projectile import Projectile
from point      import Point
from velocity   import Velocity
from bullet     import Bullet

# define
import global_variables_directory as global_variables

class Ship(Projectile):
    # initializer
    def __init__(self):
        super().__init__()

        # ship components
        self.name = "Ship"

        # Projectile components respecified
        self.center             = self.initialize_center()
        self.radius             = global_variables.SHIP_RADIUS
        self.angle_degrees      = global_variables.SHIP_ANGLE_INIT
        self.rotate_amnt        = global_variables.SHIP_ANGLE_ROTATE_AMOUNT

        # Ship draw components
        self.texture            = global_variables.SHIP_TEXTURE
        self.scale              = global_variables.SHIP_TEXTURE_SCALE
        self.alpha              = global_variables.SHIP_TEXTURE_ALPHA
        self.dark_mode          = global_variables.DARK_MODE_INIT

    def initialize_center(self):
        return Point(
            global_variables.SHIP_X_INIT,
            global_variables.SHIP_Y_INIT - 125)

    """
    methods
    """

    """
    HIT
    """
    def hit(self):
        super().hit()
        self.__init__()

    """
    DRAW
    """
    def draw(self):
        arcade.draw_scaled_texture_rectangle(
            self.center.x, 
            self.center.y, 
            self.texture, 
            self.scale, 
            self.rotation, 
            self.alpha)

    """
    ROTATE
    """
    def rotate_left(self):  self.rotation += global_variables.SHIP_ANGLE_ROTATE_AMOUNT
    def rotate_right(self): self.rotation -= global_variables.SHIP_ANGLE_ROTATE_AMOUNT

    """
    ACCELERATE
    """
    def accelerate(self):
        # get current speed
        current_v       = self.velocity

        # get acceleration and d_v amounts
        acceleration    = global_variables.SHIP_THRUST_ACCELERATE_AMOUNT
        dx, dy          = self.velocity_calculator.speed_to_dx_dy_degrees(acceleration, self.rotation + 90)
        d_v             = Velocity(dx, dy)

        # check if current speed has gone over speed limit
        if ((abs(current_v.dx + d_v.dx) > global_variables.SHIP_MAX_VELOCITY) or
            (abs(current_v.dy + d_v.dy) > global_variables.SHIP_MAX_VELOCITY)):
            self.velocity.speed -= 1

        # if not, then ACCELERATE!!!!! hehe
        else: self.velocity += d_v

    """
    FIRE
    """
    def fire(self):
        # BULLET LOCATION
        # new bullet position: (Point object)
        bullet_location = Point(self.location.x, self.location.y)

        # BULLET VELOCITY
        # add bullet speed
        dx, dy = self.velocity_calculator.speed_to_dx_dy_degrees(
            global_variables.BULLET_SPEED, self.rotation + 90)
        bullet_velocity = Velocity(dx, dy)

        # add ship speed
        bullet_velocity += self.velocity

        # BULLET DRAW ROTATION
        rotation = self.rotation

        # debug

        # fire new bullet
        return Bullet(bullet_location, bullet_velocity, rotation)

    """
    DEBUG
    """
    def debug(self):
        super().debug()
        if True:
            print(f"{self.name} Point:    ({self.center.x   }, {self.center.y   })")
            print(f"{self.name} Velocity: ({self.velocity.dx}, {self.velocity.dy})")

# Rendered as a rectangle.
# The aim is controlled to match the mouse cursor.


class Ship_Lives_Icon(Ship):
    def __init__(self, p_init: Point):
        super().__init__()
        # ship lives variabels
        self.name = "Ship lives icon"

        # projectile variables respecified
        self.center = p_init
        self.scale  = global_variables.SHIP_LIVES_DRAWING_SCALE

    # override self.accelerate() and have it do nothing
    def accelerate(self): pass
