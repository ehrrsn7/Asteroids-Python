# import
import arcade, random, math

# import point.py
from point import Point

# These are Global constants to use throughout the game

# screen variables
SCREEN_WIDTH                    = 800
SCREEN_HEIGHT                   = 600
SCREEN_MARGIN                   = 20
# x
SCREEN_MARGIN_X                 = SCREEN_MARGIN
SCREEN_CENTER_X                 = SCREEN_WIDTH / 2
SCREEN_LEFT_X                   = SCREEN_MARGIN_X
SCREEN_RIGHT_X                  = SCREEN_WIDTH - SCREEN_MARGIN_X
# y
SCREEN_MARGIN_Y                 = SCREEN_MARGIN
SCREEN_CENTER_Y                 = SCREEN_HEIGHT / 2
SCREEN_BOTTOM_Y                 = SCREEN_MARGIN_Y
SCREEN_TOP_Y                    = SCREEN_HEIGHT - SCREEN_MARGIN_Y
# arcade.color (tuple)
SCREEN_COLOR_LIGHT              = arcade.color.WHITE
SCREEN_COLOR_DARK               = arcade.color.BLACK

# default draw variables
DEFAULT_TEXTURE_ANGLE           = 0
DEFAULT_TEXTURE_SCALE           = 1
DEFAULT_TEXTURE_ALPHA           = 255

# on-screen text variables
TEXT_NORMAL_FONT_SIZE           = 12
TEXT_NORMAL_COLOR_LIGHT         = arcade.color.NAVY_BLUE
TEXT_NORMAL_COLOR_DARK          = arcade.color.WHITE

# score variables
SCORE_INIT                      = 0
SCORE_X                         = 10
SCORE_Y                         = SCREEN_TOP_Y

# level variables
LEVEL_COLOR_LIGHT               = arcade.color.NAVY_BLUE
LEVEL_COLOR_DARK                = arcade.color.WHITE
LEVEL_INIT                      = 0
LEVEL_X                         = SCREEN_WIDTH  - 65
LEVEL_Y                         = SCREEN_HEIGHT - 20
LEVEL_FONT_SIZE                 = 12

# ship variables
SHIP_X_INIT                     = SCREEN_CENTER_X
SHIP_Y_INIT                     = SCREEN_CENTER_Y
SHIP_RADIUS                     = 30
SHIP_ANGLE_ROTATE_AMOUNT        = 3
SHIP_THRUST_ACCELERATE_AMOUNT   = 0.25
SHIP_FIRING_RATE_DELAY          = 4
SHIP_MAX_VELOCITY               = 20
SHIP_ANGLE_INIT                 = 90
SHIP_TEXTURE_FILENAME           = "images/playerShip1_orange.png"
SHIP_TEXTURE                    = arcade.load_texture(SHIP_TEXTURE_FILENAME)
SHIP_TEXTURE_SCALE              = 1
SHIP_TEXTURE_ALPHA              = 255

# ship lives variables
SHIP_LIVES_INIT_AMOUNT          = 3
SHIP_LIVES_Y_POSITION           = SCREEN_TOP_Y - 20
SHIP_LIVES_X_POSITION_INIT      = 30
SHIP_LIVES_X_POSITION_SPACING   = 40
SHIP_LIVES_DRAWING_SCALE        = .325

# rifle variables
RIFLE_WIDTH                     = 100
RIFLE_HEIGHT                    = 20
RIFLE_X_INIT                    = 0
RIFLE_Y_INIT                    = 0
RIFLE_ANGLE_INIT                = 45
RIFLE_COLOR_LIGHT               = arcade.color.DARK_RED
RIFLE_COLOR_DARK                = arcade.color.LIGHT_CRIMSON

# bullet variables
BULLET_RADIUS                   = 3
BULLET_SPEED                    = 10
BULLET_TIMER                    = 60
BULLET_COLOR_LIGHT              = arcade.color.BLACK_OLIVE
BULLET_COLOR_DARK               = arcade.color.LIGHT_GRAY
BULLET_TEXURE_FILENAME          = "images/laser_bullet.png"
BULLET_TEXURE                   = arcade.load_texture(BULLET_TEXURE_FILENAME)
BULLET_TEXTURE_SCALE            = 1
BULLET_TEXTURE_ALPHA            = 255

# rock variables
ROCK_INIT_AMOUNT                = 5
# default rock variables
ROCK_DEFAULT_RADIUS             = 15
ROCK_DEFAULT_SPEED              = 1.5
ROCK_DEFAULT_POINTS_AWARDED     = 20
ROCK_DEFAULT_TIMER_INIT         = 100
ROCK_DEFAULT_SCALE              = 1
ROCK_DEFAULT_ANGLE              = 0
ROCK_DEFAULT_ALPHA              = 255
ROCK_DEFAULT_TEXTURE_FILENAME   = "images/meteorGrey_big1.png"
ROCK_DEFAULT_TEXTURE            = arcade.load_texture(ROCK_DEFAULT_TEXTURE_FILENAME)
ROCK_DEFAULT_SPIN               = 1
# big rock variables
ROCK_BIG_RADIUS                 = ROCK_DEFAULT_RADIUS
ROCK_BIG_SPEED                  = ROCK_DEFAULT_SPEED
ROCK_BIG_POINTS_AWARDED         = ROCK_DEFAULT_POINTS_AWARDED
ROCK_BIG_SPIN                   = ROCK_DEFAULT_SPIN
ROCK_BIG_TEXURE_FILENAME        = ROCK_DEFAULT_TEXTURE_FILENAME
ROCK_BIG_TEXURE                 = arcade.load_texture(ROCK_BIG_TEXURE_FILENAME)
ROCK_BIG_TEXTURE_SCALE          = ROCK_DEFAULT_SCALE
ROCK_BIG_TEXTURE_ALPHA          = ROCK_DEFAULT_ALPHA
# medium rock variables
ROCK_MEDIUM_RADIUS              = 5
ROCK_MEDIUM_SPEED               = 2
ROCK_MEDIUM_POINTS_AWARDED      = 50
ROCK_MEDIUM_SPIN                = -2
ROCK_MEDIUM_TEXURE_FILENAME     = "images/meteorGrey_med1.png"
ROCK_MEDIUM_TEXURE              = arcade.load_texture(ROCK_MEDIUM_TEXURE_FILENAME)
ROCK_MEDIUM_TEXTURE_SCALE       = 1
ROCK_MEDIUM_TEXTURE_ALPHA       = 255
# small rock variables
ROCK_SMALL_RADIUS               = 2
ROCK_SMALL_SPEED                = 3
ROCK_SMALL_POINTS_AWARDED       = 100
ROCK_SMALL_SPIN                 = 5
ROCK_SMALL_TEXURE_FILENAME      = "images/meteorGrey_small1.png"
ROCK_SMALL_TEXURE               = arcade.load_texture(ROCK_SMALL_TEXURE_FILENAME)
ROCK_SMALL_TEXTURE_SCALE        = 1
ROCK_SMALL_TEXTURE_ALPHA        = 255

# saucer variables
SAUCER_POINTS_AWARDED           = 200
SAUCER_LARGE_POINTS_AWARDED     = 1000

# target variables
TARGET_DEFAULT_RADIUS           = 20
TARGET_DEFAULT_X_INIT           = 1
# default target
TARGET_STANDARD_POINTS          = 1
TARGET_STANDARD_COLOR_DARK      = arcade.color.BLIZZARD_BLUE
TARGET_STANDARD_COLOR_LIGHT     = arcade.color.CARROT_ORANGE
# strong target
TARGET_STRONG_POINTS            = 3
TARGET_STRONG_LIFE_INIT         = 3
TARGET_STRONG_LIFE_TEXT_SIZE    = 20
TARGET_STRONG_LIFE_TEXT_OFFSET  = -10
TARGET_STRONG_COLOR_DARK        = arcade.color.LIGHT_CORAL
TARGET_STRONG_COLOR_LIGHT       = arcade.color.BLIZZARD_BLUE
TARGET_STRONG_LIFE_COLOR_DARK   = arcade.color.BLACK
TARGET_STRONG_LIFE_COLOR_LIGHT  = arcade.color.DARK_GRAY
# safe target
TARGET_SAFE_POINTS              = -10
TARGET_SAFE_SIDE_LENGTH         = TARGET_DEFAULT_RADIUS * 2
TARGET_SAFE_TILT                = 0
TARGET_SAFE_COLOR_LIGHT         = arcade.color.BLACK
TARGET_SAFE_COLOR_DARK          = arcade.color.WHITE
# meme guy target
TARGET_MEME_GUY_IMAGE_SCALE     = 1 / 10
TARGET_MEME_GUY_IMAGE_ANGLE     = 0
TARGET_MEME_GUY_IMAGE_ALPHA     = 255

# ball variables (pong)
BALL_RADIUS                     = 10
BALL_X_INIT                     = 50
BALL_Y_INIT                     = random.randint(0, SCREEN_HEIGHT)
BALL_DX_INIT                    = random.randint(1, 5)
BALL_DY_INIT                    = random.randint(1, 5)
BALL_COLOR_DARK                 = arcade.color.WHITE
BALL_COLOR_LIGHT                = arcade.color.BLACK

# paddle variables
PADDLE_WIDTH                    = 10
PADDLE_HEIGHT                   = 50
PADDLE_X_INIT                   = SCREEN_WIDTH - 20
PADDLE_Y_INIT                   = 150
PADDLE_Y_MIN                    = 30
PADDLE_Y_MAX                    = SCREEN_HEIGHT - 30
PADDLE_COLOR_DARK               = arcade.color.WHITE
PADDLE_COLOR_LIGHT              = arcade.color.BLACK

# game state
RESUME                          = 0
PAUSE                           = 1
MAIN_MENU                       = 2
NEW_LEVEL                       = 4
GAME_OVER                       = 5
SHIP_WAS_HIT                    = 6
STATE_INIT                      = MAIN_MENU
GAMESTATE_POSITION_X            = SCREEN_CENTER_X - 80
GAMESTATE_POSITION_Y            = SCREEN_TOP_Y

# game state draw variables
MAIN_MENU_IMAGE_FILENAME        = "images/asteroids_game_welcome_screen.png"
MAIN_MENU_IMAGE_TEXTURE         = arcade.load_texture(MAIN_MENU_IMAGE_FILENAME)
SHIP_WAS_HIT_IMAGE_FILENAME     = "images/ship_was_hit_msg.png"
SHIP_WAS_HIT_IMAGE_TEXTURE      = arcade.load_texture(SHIP_WAS_HIT_IMAGE_FILENAME)
GAME_OVER_IMAGE_FILENAME        = "images/game_over_msg.png"
GAME_OVER_IMAGE_TEXTURE         = arcade.load_texture(GAME_OVER_IMAGE_FILENAME)
HINTS_IMAGE_FILENAME            = "images/hints_screen.png"
HINTS_IMAGE_TEXTURE             = arcade.load_texture(HINTS_IMAGE_FILENAME)

# other variables
MOVE_AMOUNT                     = 5
DELAY_INIT                      = 5
SCORE_HIT                       = 1
SCORE_MISS                      = 5
ALIVE                           = True
DEAD                            = False
DEBUG                           = False
DARK_MODE_INIT                  = True
PI_OVER_2                       = math.radians(90)
