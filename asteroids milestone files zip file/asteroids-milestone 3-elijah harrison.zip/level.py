"""
File:   level.py
Author: Elijah Harrison

This file contains the Level class.
"""

from point          import Point
from on_screen_text import On_Screen_Text
import arcade

# import directory, save all variables we will need
import global_variables_directory as global_variables

"""
This is the level that will be drawn at the top of the screen.
"""
class Level(On_Screen_Text):
    def __init__(self,
        level_init = global_variables.LEVEL_INIT
    ):
        super().__init__()
        # initalize level components

        # center point
        self.center    = Point(
            global_variables.LEVEL_X,
            global_variables.LEVEL_Y
        )

        # level (int) component
        self.level     = int(level_init)

    """
    DRAW
    """
    def draw(self):
        # Generate level text
        level_text = f"Level: {self.level}"

        # Draw the level
        arcade.draw_text(
            level_text, 
            start_x   = self.center.x, 
            start_y   = self.center.y, 
            font_size = self.font_size, 
            color     = self.color
        )

    """
    initialize color
    return: arcade.color ('tuple')
    """
    def initalize_color(self):
        if self.dark_mode:
            print("Level color: arcade.color.NAVY_BLUE")
            return global_variables.TEXT_NORMAL_COLOR_DARK
        else:
            print("Level color: arcade.color.WHITE")
            return global_variables.TEXT_NORMAL_COLOR_LIGHT

    """
    Operators
    """
    # +
    def __add__(self, rhs):
        # return Class_Template(new_t)
        self.level += int(rhs)

    # +=
    def __iadd__(self, rhs):
        self.level = self + int(rhs)

# Rendered as a rectangle.
# The aim is controlled to match the mouse cursor.
