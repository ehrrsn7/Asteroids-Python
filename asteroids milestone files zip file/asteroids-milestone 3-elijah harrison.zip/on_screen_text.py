"""
File: on_screen_text.py
Name: Elijah Harrison

Course:     CS 241
Instructor: Brother Mellor
"""

# include
import arcade
from point import Point

# import directory, save all variables we will need
import global_variables_directory as global_variables

"""
This is the class with definitions used by all
on screen text.
"""
class On_Screen_Text:
    def __init__(self,
        text:       str     = "", 
        p:          Point   = Point(),
        font_size:  float   = 0,
    ):

        self._text      = text
        x               = global_variables.SCREEN_WIDTH
        x               /= 2
        y               = global_variables.SCREEN_HEIGHT
        y               /= 2
        self.p          = Point(x, y)
        self.font_size  = global_variables.TEXT_NORMAL_FONT_SIZE
        self.color      = global_variables.TEXT_NORMAL_COLOR_DARK

        self.display_text = False

    """
    Properties
    """
    @property
    def text(self): return self._text

    @text.setter
    def text(self, new_text: str): self._text = new_text

    """
    DRAW
    """
    def draw(self):
        """
        A default method for easy use by Skeet
        """
        if self.display_text:
            arcade.draw_text(
                self.text       ,
                self.p.x        ,
                self.p.y        ,
                self.color      ,
                self.font_size   )



"""
Class: Level
"""
class Level(On_Screen_Text):
    # initializer
    def __init__(self):
        super().__init__()
        # position
        x           = global_variables.LEVEL_X
        y           = global_variables.LEVEL_Y
        self.p      = Point(x, y)

        # level (int) container variable
        self.level  = global_variables.LEVEL_INIT

        # display text (bool)
        self.display_text = True

    """
    Methods
    """
    def next_level(self): self.level += 1

    """
    Text
    """
    @property
    def text(self): return f"Level: {self.level}"

    """
    Operators
    """
    def __iadd__(self, rhs: int): self.level += rhs
    def __isub__(self, rhs: int): self.level -= rhs

"""
Class: Score

(https://www.ign.com/faqs/2003/3-d-asteroids-general-faq-430472)
Scoring in this game is pretty simple:

Large Asteroids:     20 points
Medium Asteroids:    50 points
Small Asteroids:    100 points
Large Saucer:       200 points
Small Saucer:      1000 points.

On the normal machine set up, you earn a 
free spaceship every 10,000 points.
"""
class Score(On_Screen_Text):
    def __init__(self):
        super().__init__()

        # center point
        x       = global_variables.SCORE_X
        y       = global_variables.SCORE_Y
        self.p  = Point(x, y)

        # score count (int)
        self.score      = global_variables.SCORE_INIT

        # display text (bool)
        self.display_text = True


    """
    Text
    """
    @property
    def text(self): return f"Score: {self.score}"

    """
    Operators
    """
    # +=
    def __iadd__(self, rhs: int): self.score += rhs
    def __isub__(self, rhs: int): self.score -= rhs

