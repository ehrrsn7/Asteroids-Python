class Polar_Numbers:
    def __init__(self, magnitude: float, angle: float):
        self.magnitude  = magnitude
        self.angle      = angle
    
    def divide(self, rhs):
        new_mag = self.magnitude / rhs.magnitude
        new_ang = self.angle     - rhs.angle
        return (new_mag, new_ang)


    def __mul__(self, rhs):
        new_mag = self.magnitude * rhs.magnitude
        new_ang = self.angle     + rhs.angle
        return Polar_Numbers(new_mag, new_ang)

    def __div__(self, rhs):
        new_mag = self.magnitude / rhs.magnitude
        new_ang = self.angle     - rhs.angle
        return Polar_Numbers(new_mag, new_ang)

