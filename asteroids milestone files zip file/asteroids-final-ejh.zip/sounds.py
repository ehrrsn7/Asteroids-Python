"""
File: class_template.py
Name: Elijah Harrison

Class:      CS 241
Instructor: Brother Mellor
"""

# import
import arcade

# define
import global_variables_directory as global_variables


class Sounds_Player:
    # sounds
    fire_sound              = arcade.load_sound(global_variables.SOUND_FIRE)
    sound_explosion_large   = arcade.load_sound(global_variables.SOUND_EXPLOSION_LARGE)
    sound_explosion_medium  = arcade.load_sound(global_variables.SOUND_EXPLOSION_MEDIUM)
    sound_explosion_small   = arcade.load_sound(global_variables.SOUND_EXPLOSION_SMALL)
    sound_beat_1            = arcade.load_sound(global_variables.SOUND_BEAT_1)
    sound_beat_2            = arcade.load_sound(global_variables.SOUND_BEAT_2)
    sound_extra_ship        = arcade.load_sound(global_variables.SOUND_EXTRA_SHIP)
    sound_fire              = arcade.load_sound(global_variables.SOUND_FIRE)
    sound_air_horn          = arcade.load_sound(global_variables.SOUND_AIRHORN)
    sound_thrust            = arcade.load_sound(global_variables.SOUND_THRUST)

    troll_mode              = False

    # sound players
    def play_sound(self, sound):
        try:
            arcade.play_sound(sound)
        except ValueError:
            print("ERROR: INVALID SOUND FORMAT")
            if not global_variables.DEBUG: print("(Check asteroids.py, line 296)")
            if not global_variables.DEBUG: print()

    def play_sound_explosion_large(self):   self.play_sound(self.sound_explosion_large)
    def play_sound_explosion_medium(self):  self.play_sound(self.sound_explosion_medium)
    def play_sound_explosion_small(self):   self.play_sound(self.sound_explosion_small)
    def play_sound_beat_1(self):            self.play_sound(self.sound_beat_1)
    def play_sound_beat_2(self):            self.play_sound(self.sound_beat_2)
    def play_sound_extra_ship(self):        self.play_sound(self.sound_extra_ship)
    def play_sound_thrust(self):            self.play_sound(self.sound_thrust)
    def play_sound_fire(self):              self.play_sound(self.sound_fire)
    def play_sound_air_horn(self):          self.play_sound(self.sound_air_horn)

