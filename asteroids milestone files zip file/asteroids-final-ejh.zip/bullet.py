"""
File:   bullets.py
Author: Elijah Harrison

Class:      CS 241
Instructor: Brother Mellor

This file contains the Bullet class.
"""

import arcade

from point      import Point
from projectile import Projectile
from velocity   import Velocity

# import directory, save all variables we will need
import global_variables_directory as global_variables

class Bullet(Projectile):
    def __init__(self, p_init: Point, v_init: Velocity, rotation: float):
        super().__init__()

        # Bullet components
        self.name           = "Bullet"
        self.timer_init     = global_variables.BULLET_TIMER
        self.die_on_timer   = True
        self.set_timer()

        # Bullet draw() components
        self.texture        = arcade.load_texture(global_variables.BULLET_IMAGE_FILENAME)
        self.scale          = global_variables.BULLET_TEXTURE_SCALE
        self.alpha          = global_variables.BULLET_TEXTURE_ALPHA
        self.rotation       = rotation + 90

        # Projectile components respecified
        self.center         = p_init    # (to be specified when fire() is called)
        self.velocity       = v_init    # (to be specified when fire() is called)
        self.radius         = global_variables.BULLET_RADIUS

        # debug
        # self.debug()

    """
    methods
    """

    """
    DRAW
    """
    def draw(self):
        if self.timer < global_variables.BULLET_TIMER - 5:
            arcade.draw_scaled_texture_rectangle(
                self.center.x, 
                self.center.y, 
                self.texture, 
                self.scale, 
                self.rotation, 
                self.alpha)

    """
    Hit
    """
    def hit(self):
        self.alive = global_variables.DEAD
        if global_variables.DEBUG: print(f"{self.name.upper()}.hit()")

